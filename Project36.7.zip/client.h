﻿//client.h
#pragma once

int client_main();
