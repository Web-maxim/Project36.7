﻿// AutocompleteRU.h
#pragma once
#include <string>
#include <vector>
#include "DictionaryRU.h"
using namespace std;

wstring readInputWithAutocompleteRU(DictionaryRU& dict);