﻿#pragma once
// Config.h
#pragma once
#include <string>
#include <map>
using namespace std;

map<string, string> loadConfig(const string& filename);
