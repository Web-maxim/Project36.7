﻿//server.h
#pragma once

int server_main();
